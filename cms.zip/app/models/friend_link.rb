class FriendLink < ActiveRecord::Base
end
