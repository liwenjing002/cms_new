class CourseType < ActiveRecord::Base
end
