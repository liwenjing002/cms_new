class QuestionBase < ActiveRecord::Base
end
