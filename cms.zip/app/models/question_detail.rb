class QuestionDetail < ActiveRecord::Base
end
