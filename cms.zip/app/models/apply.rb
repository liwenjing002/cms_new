class Apply < ActiveRecord::Base
end
