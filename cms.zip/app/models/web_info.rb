class WebInfo < ActiveRecord::Base
end
