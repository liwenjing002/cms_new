module CourseTypesHelper
end
