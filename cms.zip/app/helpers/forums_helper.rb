module ForumsHelper
end
