module PageTempsHelper
end
