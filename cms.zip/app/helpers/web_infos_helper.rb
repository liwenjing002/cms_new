module WebInfosHelper
end
