module AppliesHelper
end
