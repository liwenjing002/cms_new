module CoursesHelper
end
