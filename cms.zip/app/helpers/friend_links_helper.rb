module FriendLinksHelper
end
