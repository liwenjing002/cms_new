# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Huanhao::Application.config.secret_token = 'b94026c94441828580a2e93547cccf6d9590072b5ba4a7303e5e383cd27a7983cf0269b490ddf4f07328fbae9eaf77fe205345c187784cfe35913993b2bc4faa'
